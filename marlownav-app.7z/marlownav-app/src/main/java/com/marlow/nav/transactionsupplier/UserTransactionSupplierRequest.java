package com.marlow.nav.transactionsupplier;

import com.marlow.nav.entity.UserAccount;
import com.marlow.nav.operations.TransactionOperations;
import com.marlow.nav.operations.UserTransactionOperations;
import com.marlow.nav.service.UserTransactionAccountService;
import com.marlow.nav.util.TransactionConstant;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.http.HttpStatus;
import org.springframework.messaging.Message;
import org.springframework.messaging.support.MessageBuilder;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClientException;
import org.springframework.web.server.ResponseStatusException;

import java.util.function.Supplier;

@Slf4j
@Service
public class UserTransactionSupplierRequest {

    @Autowired
    private UserTransactionAccountService userTransactionAccountService;

    @Bean
    public Supplier<Message<UserTransactionOperations>> withdrawalSource() {
        return () -> {
            final String accountId = TransactionConstant.RESOURCE_ACCOUNT_ID;

            try {
                final UserAccount userAccount = userTransactionAccountService.getAccount(accountId);
                if (null == userAccount) {
                    return null;
                }
            } catch (RestClientException e) {
                log.warn("Account service still starting up (unable to parse response for account " + accountId + ")");
                return null;
            } catch (ResponseStatusException e) {
                if (e.getStatus() != HttpStatus.NOT_FOUND && e.getStatus() != HttpStatus.SERVICE_UNAVAILABLE) {
                    return null;
                }
            }

            Long amount = Math.round(Math.random() * 49.0d + 1.0d);
            UserTransactionOperations withdrawRequest = TransactionOperations.builder().commandType(UserTransactionOperations.WITHDRAW).accountId(accountId)
                    .amount(amount).build();

            log.info("Sending withdrawal request: {}", withdrawRequest);

            return MessageBuilder.withPayload(withdrawRequest).setHeader(TransactionConstant.ACCOUNT_ID, accountId)
                    .build();
        };
    }

}
