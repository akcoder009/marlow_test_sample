package com.marlow.nav.util;

public class TransactionConstant {

    public static final String USER_ACCOUNT = "/useraccount/";
    public static final String RESOURCE_ACCOUNT = USER_ACCOUNT + "{accountId}";
    public static final String ACCOUNT_ID = "useraccount";

    public static final String RESOURCE_ACCOUNT_ID = "accountId";
    public static final String RESOURCE_EVENT_TYPE = "eventType";

    public static final String EVENT_ACCOUNT = "event.account";
    private TransactionConstant() throws IllegalAccessException {
        throw new IllegalAccessException("error");
    }

}
