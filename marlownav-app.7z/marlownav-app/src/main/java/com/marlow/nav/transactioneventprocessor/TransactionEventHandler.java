package com.marlow.nav.transactioneventprocessor;

import com.marlow.nav.entity.UserAccount;
import com.marlow.nav.event.TransactionEvent;
import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.streams.kstream.KStream;
import org.apache.kafka.streams.kstream.KTable;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Service;

import java.util.function.BiFunction;

@Service
@Slf4j
public class TransactionEventHandler {

    @Bean
    public BiFunction<KStream<String, TransactionEvent>, KTable<String, UserAccount>, KStream<String, TransactionEvent>> processEvent() {
        return (eventStream, accountTable) -> eventStream
                .leftJoin(accountTable, (event, userAccount) -> null == userAccount ? event : null)
                .filter((s, event) -> {
                    if (null != event) {
                        log.info("Sending user transaction event {}", event);
                    }
                    return null != event;
                });
    }

}
