package com.marlow.nav.transactioneventprocessor;

import com.marlow.nav.entity.UserAccount;
import com.marlow.nav.event.TransactionEvent;
import com.marlow.nav.operations.TransactionOperations;
import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.streams.kstream.KStream;
import org.apache.kafka.streams.kstream.KTable;
import org.springframework.context.annotation.Bean;

import java.util.function.Consumer;
import java.util.function.Function;

@Slf4j
public class TransactionEventSource {

    @Bean
    public Function<KStream<String, TransactionEvent>, KStream<String, UserAccount>> getAccountFromEvent() {
        return (eventStream) -> eventStream.mapValues((s, event) -> event.getUserAccount());
    }

    @Bean
    public Consumer<KTable<String, UserAccount>> accountSource() {
        return accountTable -> {
            accountTable.mapValues((accountId, bankAccount) -> {
                log.info("Process for account #{} : {} [{}]", accountId,
                        accountTable.queryableStoreName(), bankAccount);
                return bankAccount;
            });
        };
    }

    @Bean
    public Consumer<KTable<String, TransactionOperations>> transactionOperationsSource() {
        return commandTable -> {
            commandTable.mapValues((accountId, command) -> {
                log.info("Process Operations for source: {} [{}]", commandTable.queryableStoreName(),
                        command);
                return command;
            });
        };
    }

}
