package com.marlow.nav.operations;

import com.marlow.nav.entity.UserAccount;
import com.marlow.nav.event.TransactionEvent;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonPOJOBuilder;
import lombok.Builder;
import lombok.Value;

    @Value
    @JsonDeserialize(builder = TransactionOperations.CommandBuilder.class)
    @Builder(builderClassName = "CommandBuilder", toBuilder = true)
    public class TransactionOperations {

        String accountId;
        UserTransactionOperations userTransactionOperations;
        Long amount;

        public boolean canProcessForAccount(UserAccount userAccount) {
            return null != userTransactionOperations && userTransactionOperations.canProcessForAccount(accountId, amount, userAccount);
        }

        public TransactionEvent processForAccount(UserAccount userAccount) {
            return null == userTransactionOperations ? null : userTransactionOperations.processForAccount(accountId, amount, userAccount);
        }

        @JsonPOJOBuilder(withPrefix = "")
        public static class CommandBuilder {}

}
