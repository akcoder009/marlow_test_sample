package com.marlow.nav.event;

public enum TransactionEventType {

    WITHDRAW, DECLINED, DEPOSIT, CREDITED, DEBITED

}