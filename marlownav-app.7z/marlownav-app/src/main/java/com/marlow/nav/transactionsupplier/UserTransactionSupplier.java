package com.marlow.nav.transactionsupplier;


import com.marlow.nav.entity.UserAccount;
import com.marlow.nav.event.TransactionEvent;
import com.marlow.nav.event.TransactionEventType;
import com.marlow.nav.service.UserTransactionAccountService;
import com.marlow.nav.util.TransactionConstant;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.http.HttpStatus;
import org.springframework.integration.support.MessageBuilder;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClientException;
import org.springframework.web.server.ResponseStatusException;

import java.util.function.Supplier;

@Slf4j
@Service
public class UserTransactionSupplier {

    @Autowired
    private UserTransactionAccountService userTransactionAccountService;

    @Bean
    public Supplier<Message<TransactionEvent>> openAccount() {
        return () -> {
            final String accountId = TransactionConstant.ACCOUNT_ID;

            try {
                UserTransactionAccountService.getAccount(accountId);
                return null;
            } catch (RestClientException e) {
                log.warn("Account service still starting up (unable to parse response for account " + accountId + ")");
                return null;
            } catch (ResponseStatusException e) {
                if (e.getStatus() != HttpStatus.NOT_FOUND) {
                    return null;
                }
            }

            if (!accountOpened.compareAndSet(false, true)) {
                return null;
            }
            log.info("Requesting opening of account '{}'", accountId);

            final UserAccount userAccount = UserAccount.builder().accountId(accountId).balance(0l).build();

            final TransactionEvent transactionEvent = TransactionEvent.builder().accountId(accountId)
                    .eventType(TransactionEventType.OPENED).bankAccount(userAccount).build();

            log.info("Sending account event: {}", userAccount);

            return MessageBuilder.withPayload(transactionEvent).setHeader("messageKey", accountId)
                    .setHeader(TransactionConstant.ACCOUNT_ID, accountId)
                    .setHeader(TransactionConstant.RESOURCE_EVENT_TYPE, transactionEvent.getEventType()).build();
        };
    }

}
