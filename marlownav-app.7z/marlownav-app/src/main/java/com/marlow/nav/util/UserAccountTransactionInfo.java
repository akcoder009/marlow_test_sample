package com.marlow.nav.util;

import com.marlow.nav.service.UserTransactionAccountService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestClientException;
import org.springframework.web.server.ResponseStatusException;

@Component
@Slf4j
public class UserAccountTransactionInfo {

        @Autowired
        private UserTransactionAccountService userTransactionAccountService;

        @Scheduled(fixedRate = 5_000)
        public void printAccountState() {
            log.info("-----------------------------------");
            try {
                log.info("Account state: {}", userTransactionAccountService.getAccount(TransactionConstant.RESOURCE_ACCOUNT_ID));
            } catch (RestClientException e) {
                log.warn(
                        "Account service starting up (unable to parse response for account " + TransactionConstant.RESOURCE_ACCOUNT_ID + ")");
            } catch (ResponseStatusException e) {
                if (e.getStatus() == HttpStatus.SERVICE_UNAVAILABLE) {
                    log.warn("Account [id: '{}'] not yet available", TransactionConstant.RESOURCE_ACCOUNT_ID);
                } else if (e.getStatus() == HttpStatus.NOT_FOUND) {
                    log.warn("Account [id: '{}'] not found", TransactionConstant.RESOURCE_ACCOUNT_ID);
                } else {
                    log.error("Failed to fetch account " + TransactionConstant.RESOURCE_ACCOUNT_ID, e);
                }
            } catch (RuntimeException e) {
                log.error("Failed to fetch account " + TransactionConstant.RESOURCE_ACCOUNT_ID, e);
            }
            log.info("-----------------------------------");
        }
}
