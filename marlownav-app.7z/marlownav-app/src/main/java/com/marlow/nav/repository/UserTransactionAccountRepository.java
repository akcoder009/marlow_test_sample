package com.marlow.nav.repository;

import com.marlow.nav.entity.UserAccount;
import com.marlow.nav.util.TransactionConstant;
import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.common.serialization.StringSerializer;
import org.apache.kafka.streams.state.HostInfo;
import org.apache.kafka.streams.state.QueryableStoreTypes;
import org.apache.kafka.streams.state.ReadOnlyKeyValueStore;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.stream.binder.kafka.streams.InteractiveQueryService;
import org.springframework.stereotype.Repository;
import org.springframework.web.client.RestTemplate;

@Slf4j
@Repository
public class UserTransactionAccountRepository {

    @Autowired
    private InteractiveQueryService interactiveQueryService;

    public UserAccount getAccount(String accountId) {
        HostInfo hostInfo = interactiveQueryService
                .getHostInfo(TransactionConstant.EVENT_ACCOUNT, accountId, new StringSerializer());

        if (null == hostInfo || null == hostInfo.host()) {
            throw new IllegalStateException("Unable to determine host responsible for the account");
        }

        if (interactiveQueryService.getCurrentHostInfo().equals(hostInfo)) {
            log.debug("Fetching account from local host {}:{}", hostInfo.host(), hostInfo.port());
            final ReadOnlyKeyValueStore<String, UserAccount> accountStore = interactiveQueryService
                    .getQueryableStore(TransactionConstant.EVENT_ACCOUNT,
                            QueryableStoreTypes.<String, UserAccount>keyValueStore());

            return accountStore.get(accountId);
        } else {
            log.debug("Fetching account from remote host {}:{}", hostInfo.host(), hostInfo.port());

            RestTemplate restTemplate = new RestTemplate();
            return restTemplate.getForEntity(String.format("http://%s:%d%s%s", hostInfo.host(), hostInfo.port(),
                    TransactionConstant.USER_ACCOUNT, accountId), UserAccount.class).getBody();
        }
    }

}