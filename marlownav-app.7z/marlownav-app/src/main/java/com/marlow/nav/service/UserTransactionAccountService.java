package com.marlow.nav.service;

import com.marlow.nav.entity.UserAccount;
import com.marlow.nav.repository.UserTransactionAccountRepository;
import com.marlow.nav.util.TransactionConstant;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;

@RestController()
@Slf4j
public class UserTransactionAccountService {

        @Autowired
        private UserTransactionAccountRepository userTransactionAccountRepository;

        @RequestMapping(TransactionConstant.RESOURCE_ACCOUNT)
        public UserAccount getAccount(@RequestParam(value = "accountId") String accountId) {
            if (null == accountId || accountId.isEmpty()) {
                throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "No id input");
            }

            try {
                final UserAccount account = userTransactionAccountRepository.getAccount(accountId);
                if (account == null) {
                    throw new ResponseStatusException(HttpStatus.NOT_FOUND, "account not found");
                }
                return account;
            } catch (IllegalStateException e) {
                throw new ResponseStatusException(HttpStatus.SERVICE_UNAVAILABLE, "Unable to process request");
            }
        }

}
