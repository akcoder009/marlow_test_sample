package com.marlow.nav.operations;

import com.marlow.nav.entity.UserAccount;
import com.marlow.nav.event.TransactionEvent;
import com.marlow.nav.event.TransactionEventType;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public enum UserTransactionOperations {
    DEPOSIT {
        @Override
        protected TransactionEvent processForAccount(String accountId, Long amount, UserAccount userAccount) {
            validateAccountPreconditions(accountId, amount, userAccount);

            log.info("Processing {} (amount: {}) for user account {}", this, amount, userAccount);

            final UserAccount newAccountState = UserAccount.builder().accountId(userAccount.getAccountId())
                    .balance(userAccount.getBalance() + amount).build();

            return TransactionEvent.builder().accountId(userAccount.getAccountId())
                    .eventType(TransactionEventType.CREDITED).amount(amount).userAccount(newAccountState).build();
        }

        @Override
        protected void validateAccountPreconditions(String accountId, Long amount, UserAccount userAccount) {
            if (!accountId.equals(userAccount.getAccountId())) {
                throw new IllegalStateException("Request is not for provided account details");
            }
        }
    }, WITHDRAW {
        @Override
        protected TransactionEvent processForAccount(String accountId, Long amount, UserAccount userAccount) {
            validateAccountPreconditions(accountId, amount, userAccount);

            log.info("Processing {} (amount: {}) for user account {}", this, amount, userAccount);

            final UserAccount newAccountState = UserAccount.builder().accountId(userAccount.getAccountId())
                    .balance(userAccount.getBalance() - amount).build();

            return TransactionEvent.builder().accountId(userAccount.getAccountId())
                    .eventType(TransactionEventType.DEBITED).amount(amount).userAccount(newAccountState).build();
        }

        @Override
        protected void validateAccountPreconditions(String accountId, Long amount, UserAccount userAccount) {
            if (!accountId.equals(userAccount.getAccountId())) {
                throw new IllegalStateException("Withdrawal request is not for provided account details");
            }

            if (userAccount.getBalance() < amount) {
                throw new IllegalStateException("Insufficient funds to process withdrawal request");
            }
        }

    };

    abstract protected TransactionEvent processForAccount(String accountId, Long amount, UserAccount userAccount);

    abstract protected void validateAccountPreconditions(String accountId, Long amount, UserAccount userAccount);

    boolean canProcessForAccount(String accountId, Long amount, UserAccount userAccount) {
        try {
            validateAccountPreconditions(accountId, amount, userAccount);
            return true;
        } catch (IllegalStateException e) {
            return false;
        }
    }

}
