package com.marlow.nav.entity;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonPOJOBuilder;
import lombok.Builder;
import lombok.Value;

@Value
@JsonDeserialize(builder = UserAccount.UserAccountBuilder.class)
@Builder(builderClassName = "UserAccountBuilder", toBuilder = true)
public class UserAccount {

        String accountId;
        Long balance;

        @JsonPOJOBuilder(withPrefix = "")
        public static class UserAccountBuilder {}

}
