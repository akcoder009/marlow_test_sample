package com.marlow.nav.event;

import com.marlow.nav.entity.UserAccount;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonPOJOBuilder;
import lombok.Builder;
import lombok.Value;

@Value
@JsonDeserialize(builder = TransactionEvent.TransactionEventBuilder.class)
@Builder(builderClassName = "AccountEventBuilder", toBuilder = true)
public class TransactionEvent {

    String accountId;
    TransactionEventType eventType;
    Long amount;
    UserAccount userAccount;

    @JsonPOJOBuilder(withPrefix = "")
    public static class TransactionEventBuilder {}

}
